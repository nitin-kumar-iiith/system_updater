#!/bin/bash
sh -c "/home/"$(whoami)"/.config/updateMGR/root_shell/root_shell4.sh; exec bash"